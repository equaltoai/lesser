module github.com/aws/aws-sdk-go-v2/internal/endpoints/v2

go 1.22

require (
	github.com/aws/aws-sdk-go-v2 v1.38.0
	github.com/aws/smithy-go v1.22.5
)

replace github.com/aws/aws-sdk-go-v2 => ../../../
